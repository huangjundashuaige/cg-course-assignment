cp ./libglut.so.3 /usr/lib/
